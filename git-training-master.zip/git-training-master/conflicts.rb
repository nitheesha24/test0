class HelloWorld
  def initialize
    output_lines
  end

  def output_lines
    puts 'Line1'
    puts 'Line2'
    puts 'Line3'
  end
end

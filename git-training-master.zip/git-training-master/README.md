# GitLab Training Examples

Example files for use during the user training workshops.
